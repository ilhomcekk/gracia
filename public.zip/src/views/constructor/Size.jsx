import React from 'react'

const Size = () => {
  return (
    <div>Size</div>
  )
}

export default Size